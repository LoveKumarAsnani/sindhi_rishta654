
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="page-content">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <p class="h2">Personal Information</p>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100 ">Name</label>
                                    <input class="form-label w-100 p-2" disabled
                                        value="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>" />

                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Nick Name</label>
                                    <input class="form-label w-100 p-2 <?php if(!isset($user->nick_name)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->nick_name ?? ''); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Email</label>
                                    <input class="form-label w-100 p-2" disabled value="<?php echo e($user->email ?? ''); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Username</label>
                                    <input class="form-label w-100 p-2 <?php if(!isset($user->user_name)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->user_name ?? ''); ?>" />
                                </div>
                            </div>

                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Phone Number</label>
                                    <input class="form-label w-100 p-2 <?php if(!isset($user->phone_number)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->phone_number); ?>" />
                                </div>

                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Gender</label>
                                    <input class="form-label w-100 p-2 <?php if(!isset($user->gender)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php if($user->gender == '1'): ?> Male <?php else: ?> Female <?php endif; ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Email Verified</label>
                                    <input class="form-label w-100 p-2" disabled
                                        value="<?php if($user->is_email_verified == '1'): ?> Verified <?php else: ?> Unverified <?php endif; ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">User Status</label>
                                    <input class="form-label w-100 p-2" disabled
                                        value="<?php if($user->status == '0'): ?> Unverified <?php elseif($user->status == '1'): ?> Verified <?php else: ?> Blocked <?php endif; ?>" />
                                </div>
                            </div>

                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Surname</label>
                                    <input class="form-label w-100 p-2 <?php if(!isset($user->profile->surname)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->surname ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Caste</label>
                                    <input class="form-label w-100 p-2 <?php if(!isset($user->profile->caste)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->caste ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Community</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->community)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->community ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Religion</label>
                                    <input class="form-label w-100 p-2"
                                        <?php if(isset($user->profile->religion)): ?> text-danger <?php endif; ?> disabled
                                        value="<?php echo e($user->profile->religion ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Date of Birth</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->date_of_birth)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->date_of_birth ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Martial Status</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->martial_status)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->martial_status ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Mother Tongue</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->mother_tongue)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->mother_tongue ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Physical Status</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->physical_status)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->physical_status ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Alcholic</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->alcoholic)): ?> text-danger <?php endif; ?>"
                                        disabled
                                        value="<?php if($user->profile->alcoholic == '0'): ?> No <?php elseif($user->profile->alcoholic == '1'): ?> Yes <?php endif; ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Vegetarian</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->vegetarian)): ?> text-danger <?php endif; ?>"
                                        disabled
                                        value="<?php if($user->profile->vegetarian == '0'): ?> No <?php elseif($user->profile->vegetarian == '1'): ?> Yes <?php endif; ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Height</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->height)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->height ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Weight</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->weight)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->weight ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Bio</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->bio)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->bio ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <p class="h2">Location Information</p>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">State</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->state)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->state ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Country</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->country)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->country ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">City</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->city)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->city ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Home Town</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->home_town)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->home_town ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <p class="h2">Family Information</p>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Father Name</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->father_name)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->father_name ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Father Occupation</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->father_occupation)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->father_occupation ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Grand Father Name</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->grand_father_name)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->grand_father_name ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Mother Name</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->mother_name)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->mother_name ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Mother From</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->mother_from)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->mother_from ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Brothers</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->brothers)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->brothers ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Sisters</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->sisters)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->sisters ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Brothers Married</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->brothers_married)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->brothers_married ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Sisters Married</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->sisters_married)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->sisters_married ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <p class="h2">Education and Professional Information</p>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Highest Education</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->highest_education)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->highest_education ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Degree</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->degree)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->degree ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Occupation</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->occupation)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->occupation ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Job Type</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->job_type)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->job_type ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Salary</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->salary)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->salary ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Currency</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->currency)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->currency ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <p class="h2">General Information</p>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Skin Color</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->skin_color)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->skin_color ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Guardian Phone Number</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->guardian_phone_number)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->guardian_phone_number ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Blood Group</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->blood_group)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->blood_group ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">TIme to Call</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->time_to_call)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->time_to_call ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Father Alive</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->father_alive)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->father_alive ?? 'Not Given'); ?>" />
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Mother Alive</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->mother_alive)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->mother_alive ?? 'Not Given'); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-6">
                                    <label class="form-label w-100">Horoscope</label>
                                    <input
                                        class="form-label w-100 p-2 <?php if(!isset($user->profile->horoscope)): ?> text-danger <?php endif; ?>"
                                        disabled value="<?php echo e($user->profile->horoscope ?? 'Not Given'); ?>" />
                                </div>

                            </div>

                            <div class="mb-3 ">
                                <?php $__empty_1 = true; $__currentLoopData = $user->pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <img src="<?php echo e(public_path('pictures/')); ?>/<?php echo e($picture->image_name); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="text-danger">
                                        No Image Found
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\personal_projects\sindhi_rishta\resources\views/admin/users/show.blade.php ENDPATH**/ ?>