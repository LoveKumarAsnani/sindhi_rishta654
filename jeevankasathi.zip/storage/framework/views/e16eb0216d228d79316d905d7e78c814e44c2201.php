  
<?php /**PATH C:\xampp\htdocs\personal_projects\sindhi_rishta\resources\views/layouts/admin/admin-rightsidebar.blade.php ENDPATH**/ ?>