            <!-- ========== Left Sidebar Start ========== -->
            <div class="vertical-menu">

                <div data-simplebar class="h-100">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title" key="t-menu">Menu</li>

                            <li>
                                <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect">
                                    <i class="bx bx-home-circle"></i><span
                                        class="badge rounded-pill bg-info float-end"></span>
                                    <span key="t-dashboards">Dashboard</span>
                                </a>
                                
                            </li>
                            <li>
                                <a href="javascript: void(0);" class="waves-effect">
                                    <i class="bx bx-briefcase-alt-2"></i>
                                    <span class="badge rounded-pill bg-info float-end"></span>
                                    <span key="t-dashboards">Users</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    <li><a href="<?php echo e(route('admin.users.index')); ?>" key="t-saas">Listing</a></li>
                                </ul>
                            </li>
                            
                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->
<?php /**PATH C:\xampp\htdocs\personal_projects\sindhi_rishta\resources\views/layouts/admin/admin-leftsidebar.blade.php ENDPATH**/ ?>