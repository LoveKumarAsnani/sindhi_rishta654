Hello <?php echo e($user->name); ?>

Thank You for create an account please verify your email using this link:
<?php echo e(route('verify',$user->verification_token)); ?>

<?php /**PATH C:\xampp\htdocs\personal_projects\sindhi_rishta\resources\views/emails/welcome.blade.php ENDPATH**/ ?>