<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('assets/front/css/custom_css.css') }}">
<link rel="stylesheet" href="{{ asset('assets/front/css/responsive.css') }}">
{{-- <link rel="icon" href="{{ asset('assets/images/favicon.png') }}" sizes="16x16"> --}}
<link rel="stylesheet" href="{{ asset('assets/front/fontawesome/css/all.min.css') }}">
